import random

class Magic8Ball(object):

    def __init__(self, answers=[]):
        'the constructor'
##        if len(answers)==0:
##            answers.append('It is certain')
##            answers.append('It is decidedly so')
##            answers.append('Without a doubt')
##            answers.append('Yes definitely')
##            answers.append('You may rely on it')
##            answers.append('As I see it, yes')
##            answers.append('Most likely')
##            answers.append('Outlook good')
##            answers.append('Yes')
##            answers.append('Signs point to yes')
##            answers.append('Reply hazy try again')
##            answers.append('Ask again later')
##            answers.append('Better not tell you now')
##            answers.append('Cannot predict now')
##            answers.append('Concentrate and ask again')
##            answers.append("Don't count on it")
##            answers.append('My reply is no')
##            answers.append('My sources say no')
##            answers.append('Outlook not so good')
##            answers.append('Very doubtful')
        pass

    def shake(self):
        'get the next answer'
        pass

    def get(self):
        'get the current answer'
        pass

    def numAnswers(self):
        'get the number of answers in the ball'
        pass

    def __iter__(self):
        'get the iterator'
        pass

    def __str__(self):
        'string representation'
        pass



import random
class Cookie(object):

    #built in cookies, other cookies are allowed
    cookieTypes=('chocolate chip','peanut butter','oatmeal','mint chocolate','raisin','vegan')
    
    def __init__(self,cookieType=None):
        'constructor. Assigns a cookie name or randomly picks one from the built in cookie types'
        if cookieType==None:
            self.__cookie = self.cookieTypes[random.randint(0,len(self.cookieTypes)-1)]
        else:
            self.__cookie = cookieType

    def getCookieType(self):
        'return the cookie type'
        return self.__cookie

    def __str__(self):
        'string representation of cookie'
        return self.__cookie

    def __repr__(self):
        'pythin representation of cookie'
        return "Cookie('{}')".format(self.__cookie)

class CookieJar(object):
    pass
