def sums(lst):
    pass

print(sums([1,2,3,4,5]))
print(sums([[[[[1]]]],2,[3,4],5]))

    
import os

def count(pathname, name):
    pass
