print("This is a simple file.")
print("There is no virus here!")

